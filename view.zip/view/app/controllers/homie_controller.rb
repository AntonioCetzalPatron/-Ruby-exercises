class HomieController < ApplicationController
  def index
  end
end
